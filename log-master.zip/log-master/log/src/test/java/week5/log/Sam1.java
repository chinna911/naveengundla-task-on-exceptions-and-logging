package week5.log;

import java.io.*;
public class Sam1
{ 
	 
 public static void main(String args[]) 
 {
	 System.out.println("");
	 Interest obj=new Interest();
	 obj.sim();
 }

} 
