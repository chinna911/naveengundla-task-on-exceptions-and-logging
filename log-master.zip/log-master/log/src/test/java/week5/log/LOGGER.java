package week5.log;

public class LOGGER {

	public static void info(String string) {
		// TODO Auto-generated method stub
		
	}

}
