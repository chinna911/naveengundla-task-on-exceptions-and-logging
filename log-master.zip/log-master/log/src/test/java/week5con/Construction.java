package week5con;


import java.io.*;

public class Construction {
	public static void main(String[] args)  {
	
		Cost c = new Cost();
        c.con();
	}

}